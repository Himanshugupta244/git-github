import java.util.Scanner;

public class GetParticipantScoreSum {
	
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		System.out.println("Please enter the participants number");
		int partipantCount = s.nextInt();
		System.out.println("partipantCount is :: " + partipantCount);
		
		
	}
	
	

}
