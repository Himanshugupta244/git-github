import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.CharMatcher;

public class Deployment_CLOUDE {

	static WebDriver driver   = null;
	static String environment = null;
	static String username    = "hgupta";
	static String CMTpassword = "Happy@2021";
	static String LANpassword = "Tsys@2027";
	static String Envrionmnt  = null;
	static String Branch      = null;
	static String messageBody = null;
	static StringBuilder sb = new StringBuilder();
	static String uname = null;
	private static final String DATA_FOR_RANDOM_STRING = "abcdefghijklmnopqrstuvwxyz" + "1234567890";
	private static SecureRandom random = new SecureRandom();
	public static void main(String[] args) {

		sb.append("  <tr>");
		sb.append ("  </tr>");
		sb.append("  <b>");
		sb.append(" Deployment details are :- ");
		sb.append ("  </b>");
		System.out.println("---- Deployment details are ---- ");
		sb.append("  <tr>");
		sb.append ("  </tr>");
		sb.append("  <tr>");
		sb.append ("  </tr>");
		String path = System.getProperty("user.dir");
		path = path + "\\chromedriver.exe";


		//		dummyMethodforOAC();
//						deployNEO("feature/PAN-1100-Dev-for-ACH-New");
//						deployCesium("feature/PAN-1100-Dev-for-ACH-New");
//						deployHercules("feature/PAN-1100-Dev-for-ACH-New");
//					    deployOnlineAcquisition("develop");
//						deployWebNewStatic("develop");
		//				deployACP("no");
				        deployACPSB("feature/PAN-1899-dev-task-locked-out-message-in-forgot-username");
		//			    deployWebapiSB("no");
		//		        deployST("develop");
		//				deployACQUISITIONAPI_SB("no");
		//				deployACQUISITIONUI("no");
		//				deployEXTERNAL_ID_SERVICE("no");
//		azulosPlusAcquisitionScreen1("approved");
//		azulosPlusAcquisitionScreen2();
//		azulosPlusAcquisitionScreen3();
//						sendMail();
//				        NEO CESIUM and HERCULES
	}

	public static void azulosPlusAcquisitionScreen1(String CIPStatus) {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www-azulosplus-cloude.aws.netspend.net/create-account/azulos-cdda?context_name=azulosplus_hh");
		wait(1000);
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'Account opening is subject to')]")));
		wait(1000);
		driver.findElement(By.xpath(".//span[contains(text(),'First name')]")).click();
		driver.findElement(By.xpath(".//input[@name='first_name']")).sendKeys("John");
		driver.findElement(By.xpath(".//input[@name='last_name']")).sendKeys("Smith");
		driver.findElement(By.xpath(".//input[@name='addr_line1']")).sendKeys("222333 Peachtree Place");
		if(CIPStatus.equalsIgnoreCase("conditional")) {
			driver.findElement(By.xpath(".//input[@name='zip']")).sendKeys("30308");
		}else {
			driver.findElement(By.xpath(".//input[@name='zip']")).sendKeys("30318");
		}
		driver.findElement(By.xpath(".//input[@name='email']")).sendKeys("randmneww@sskh.com");
		scrollToElement(driver, driver.findElement(By.xpath(".//h4[contains(text(),'Verify')]")));
		wait(1000);
		if(CIPStatus.equalsIgnoreCase("rejected")) {
			driver.findElement(By.xpath(".//input[@name='dob']")).sendKeys("02/28/1975"); 
			wait(500);
			driver.findElement(By.xpath(".//input[@name='ssn']")).sendKeys("112223355"); 
			wait(500);
		}
		if(CIPStatus.equalsIgnoreCase("approved")) {
			driver.findElement(By.xpath(".//input[@name='dob']")).sendKeys("02/28/1965"); // 
			wait(500);
			driver.findElement(By.xpath(".//input[@name='ssn']")).sendKeys("112223333"); 
			wait(500);
		}
		if(CIPStatus.equalsIgnoreCase("conditional")) {
			driver.findElement(By.xpath(".//input[@name='dob']")).sendKeys("02/28/1965"); // 
			wait(500);
			driver.findElement(By.xpath(".//input[@name='ssn']")).sendKeys("112223333"); 
			wait(500);
		}

	}

	public static void azulosPlusAcquisitionScreen2() {
		driver.findElement(By.xpath(".//button[contains(text(),'SIGN UP')]")).click();
		waitTillElementVisible(driver, ".//h3[contains(text(),'Congratulations')]", 10);
		int rand_int1 = getRandomNumberInts(1,100000);
		int rand_int2 = getRandomNumberInts(100000,200000);
		String rand_str = generateRandomString(4);
		uname = "hgupta" + rand_int1 + rand_int2 + rand_str;
		System.out.println("username is ::" + uname);
		if(uname.length()>20) {
			uname = uname.substring(0, 20);
		}
		uname = uname.toLowerCase();
		System.out.println("updated username is ::" + uname);
		driver.findElement(By.xpath(".//input[@name='login_name']")).sendKeys(uname);
		driver.findElement(By.xpath(".//input[@name='password']")).sendKeys("Netspend1");
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'Must include at least:')]")));
		wait(500);
		driver.findElement(By.xpath(".//input[@name='confirmPassword']")).sendKeys("Netspend1");
		driver.findElement(By.xpath(".//select[@name='security_question']")).click();
		wait(1000);
		driver.findElement(By.xpath(".//option[contains(text(),'pet')]")).click();
		wait(500);
		driver.findElement(By.xpath(".//input[@name='security_answer']")).sendKeys("pet");
	}

	public static void azulosPlusAcquisitionScreen3() {
		driver.findElement(By.xpath(".//button[contains(text(),'Continue')]")).click();
		waitTillElementVisible(driver, ".//*[contains(text(),'Confirmation Code')]", 10);
		((JavascriptExecutor)driver).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1)); //switches to new tab
		driver.get("http://cloude-pub-web0a01.aws.netspend.net:8081/fluidapi/api/v1/ooba/code/"+uname);
		wait(1000);
		String txt = driver.findElement(By.xpath(".//pre")).getText();
		String digits = CharMatcher.inRange('0', '9').retainFrom(txt);
		System.out.println("OOBA is  :: " + digits);
		driver.switchTo().window(tabs.get(0));
		wait(1000);
		driver.findElement(By.xpath(".//input[@name='code_attempt']")).sendKeys(digits);
		driver.findElement(By.xpath(".//button[contains(text(),'SUBMIT')]")).click();
	}

	public static void deployWebNewStatic(String branchName) {
		environment = "STATIC";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'Webnew-Static')]")));
		wait(1000);
		driver.findElement(By.xpath(".//input[@id='Webnew-Static']")).click();
		submitAndGetDeploymentLink();
	}

	public static void dummyMethodforOAC() {
		for(int count=0;count<70;count++) {
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://www-netspend-cloude.aws.netspend.net/account/login");
			waitTillElementVisible(driver, ".//input[@name='username']", 5);
			driver.findElement(By.xpath(".//input[@name='username']")).sendKeys("fluid-l2nsii52qv");
			driver.findElement(By.xpath(".//input[@name='password']")).sendKeys("Netspend1");
			driver.findElement(By.xpath(".//button[@type='submit']")).click();
			wait(5000);
			driver.navigate().refresh();
			//		waitTillElementVisible(driver, ".//span[contains(text(),'Account')]", 5);
			//		driver.findElement(By.xpath(".//span[contains(text(),'Account')]")).click();
			//		wait(2000);
			//		scrollToElement(driver, driver.findElement(By.xpath(".//p[contains(text(),'Logout')]")));
			//		wait(500);
			//		driver.findElement(By.xpath(".//p[contains(text(),'Logout')]")).click();
			driver.quit();
		}
	}

	public static void openCMT() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://cmtdashboard.test.aus.netspend.net/index.php");
		driver.findElement(By.xpath(".//input[@id='username']")).sendKeys(username);
		driver.findElement(By.xpath(".//input[@name='passwd']")).sendKeys(CMTpassword);
		driver.findElement(By.xpath(".//input[@name='submit']")).click();
	}

	public static void deployNEO(String branchName) {
		environment = "NEO";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'NEO')]")));
		wait(1000);
		driver.findElement(By.xpath(".//input[@id='NEO']")).click();
		submitAndGetDeploymentLink();
	}

	public static void deployCesium(String branchName) {
		environment = "CESIUM";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'Cesium-ACH')]")));
		wait(500);
		driver.findElement(By.xpath(".//input[@id='Cesium-ACH']")).click();
		wait(500);
		driver.findElement(By.xpath(".//input[@id='Cesium-Cardorder']")).click();
		wait(500);
		driver.findElement(By.xpath(".//input[@id='Cesium-Other']")).click();
		wait(500);
		driver.findElement(By.xpath(".//input[@id='Cesium-Transmsg']")).click();
		wait(500);
		submitAndGetDeploymentLink();
	}

	public static void deployHercules(String branchName) {
		environment = "HERCULES";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'Hercules')]")));
		wait(1000);
		driver.findElement(By.xpath(".//input[@id='Hercules']")).click();
		submitAndGetDeploymentLink();
	}

	public static void deployOnlineAcquisition(String branchName) {
		environment = "ONLINEACQUISITION";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'onlineacquisition')]")));
		wait(1000);
		driver.findElement(By.xpath(".//input[@id='onlineacquisition']")).click();
		submitAndGetDeploymentLink();
	}

	public static void deployACP(String branchName) {
		environment = "ACCOUNTCENTERUI";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'Account-Center-UI')]")));
		wait(1000);
		driver.findElement(By.xpath(".//input[@id='Account-Center-UI']")).click();
		submitAndGetDeploymentLink();
	}

	public static void deployACPSB(String branchName) {
		environment = "ACCOUNT_CENTER_UI_SB";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'account-center-ui-sb')]")));
		wait(1000);
		driver.findElement(By.xpath(".//input[@id='account-center-ui-sb']")).click();
		submitAndGetDeploymentLink();
	}

	public static void deployWebapiSB(String branchName) {
		environment = "WEBAPI_SB";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'webapi-sb')]")));
		wait(1000);
		driver.findElement(By.xpath(".//input[@id='webapi-sb']")).click();
		submitAndGetDeploymentLink();
	}

	public static void deployST(String branchName) {
		environment = "SPENDING_TRACKER";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'spending-tracker')]")));
		wait(1000);
		driver.findElement(By.xpath(".//input[@id='spending-tracker']")).click();
		submitAndGetDeploymentLink();
	}

	public static void deployACQUISITIONAPI_SB(String branchName) {
		environment = "ACQUISITIONAPI_SB";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'Acquisitionapi-SB')]")));
		wait(1000);
		driver.findElement(By.xpath(".//input[@id='Acquisitionapi-SB']")).click();
		submitAndGetDeploymentLink();
	}

	public static void deployACQUISITIONUI(String branchName) {
		environment = "ACQUISITIONUI";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'Acquisition-UI')]")));
		wait(1000);
		driver.findElement(By.xpath(".//input[@id='Acquisition-UI']")).click();
		submitAndGetDeploymentLink();
	}

	public static void deployEXTERNAL_ID_SERVICE(String branchName) {
		environment = "EXTERNAL_ID_SERVICE";
		openCMT();
		changeBranch(branchName, environment, driver);
		openDeploymentEnvironments();
		scrollToElement(driver, driver.findElement(By.xpath(".//span[contains(text(),'external-id-service')]")));
		wait(1000);
		driver.findElement(By.xpath(".//input[@id='external-id-service']")).click();
		submitAndGetDeploymentLink();
	}

	public static void wait(int Time) {
		try {
			Thread.sleep(Time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static int getRandomNumberInts(int min, int max){
		Random random = new Random();
		return random.ints(min,(max+1)).findFirst().getAsInt();
	}

	public static void submitAndGetDeploymentLink() {
		try {
			wait(500);
			ArrayList<String> applications = new ArrayList<String>();
			scrollToElement(driver, driver.findElement(By.xpath(".//button[contains(text(),'Submit')]")));
			waitTillElementVisible(driver,".//button[contains(text(),'Submit')]", 5);
			driver.findElement(By.xpath(".//button[contains(text(),'Submit')]")).click();
			waitTillElementVisible(driver, ".//b[contains(text(),'The following distributions will be deployed')]", 5);
			List<WebElement> apps = driver.findElements(By.xpath(".//div[@id='inner-cmt_cloud_environments']//center[4]//table[2]//tr//td//font"));
			for(int count=1;count<=apps.size();count++) {
				applications.add(apps.get(count-1).getText());
			}
			driver.findElement(By.xpath(".//button[contains(text(),'Deploy Environment')]")).click();
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert().accept();
			wait.until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert().accept();
			wait(2000);
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
			driver.switchTo().window(tabs2.get(1));
			waitTillElementVisible(driver, ".//input[@id='loginForm_os_username']", 5);
			String deploymentURL = null;
			deploymentURL = driver.getCurrentUrl();
			wait(1000);
			System.out.println();
			sb.append("  <tr>");
			sb.append ("  </tr>");
			sb.append("Application(s) : " + applications);
			sb.append("  <tr>");
			sb.append ("  </tr>");
			sb.append("Deployment link is : " + deploymentURL);
			sb.append("  <tr>");
			sb.append ("  </tr>");
			System.out.println("Application(s) : " + applications);
			System.out.println("Deployment link is : " + deploymentURL);
			System.out.println();
			driver.quit();
		}
		catch (Exception e) {
			driver.quit();
		}
	}

	public static void scrollToElement(WebDriver driver, WebElement Element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", Element);
	}

	public static void openDeploymentEnvironments() {
		waitTillElementVisible(driver, ".//a[contains(text(),'Cloud')]", 5);
		driver.findElement(By.linkText("Cloud")).click();
		waitTillElementVisible(driver, ".//a[contains(text(),'Environments')]", 5);
		driver.findElement(By.xpath(".//a[contains(text(),'Environments')]")).click();
		waitTillElementVisible(driver, ".//select[@id='mySelect']", 5);
		driver.findElement(By.id("mySelect")).click();
		driver.findElement(By.xpath(".//option[@value='deploy_environment']")).click();
		waitTillElementVisible(driver, ".//h2[contains(text(),'Deploy Distributions to Environment in the Cloud')]", 5);
		driver.findElement(By.id("keepWorkingDir")).click();
		wait(500);
		driver.findElement(By.xpath(".//select[@id='keepWorkingDir']//option[contains(text(),'true')]")).click();
		wait(500);
	}

	public static void changeBranch(String branchName, String environment,WebDriver driver) {
		branchName = branchName.toLowerCase();
		if(!branchName.equalsIgnoreCase("NO")) {
			waitTillElementVisible(driver, ".//a[contains(text(),'Cloud')]", 5);
			driver.findElement(By.linkText("Cloud")).click();
			waitTillElementVisible(driver, ".//a[contains(text(),'Environments')]", 5);
			driver.findElement(By.xpath(".//a[contains(text(),'Environments')]")).click();
			waitTillElementVisible(driver, ".//select[@id='mySelect']", 5);
			wait(500);
			driver.findElement(By.id("mySelect")).click();
			waitTillElementVisible(driver, ".//option[@value='deployable_branches']", 2);
			driver.findElement(By.xpath(".//option[@value='deployable_branches']")).click();
			waitTillElementVisible(driver, ".//h2[contains(text(),'Deployable branches')]", 5);
			scrollToElement(driver, driver.findElement(By.xpath(".//font[contains(text(),'"+environment+"_BRANCH')]")));
			waitTillElementVisible(driver, ".//font[contains(text(),'"+environment+"_BRANCH')]", 5);
			if(!driver.findElement(By.xpath(".//font[contains(text(),'"+environment+"_BRANCH')]/parent::td/following-sibling::td[2]/font")).getText().toLowerCase().contains(branchName)) {
				driver.findElement(By.xpath(".//a[contains(@onclick,'"+environment+"_BRANCH')]")).click();
				waitTillElementVisible(driver, ".//span[contains(text(),'Where is my branch')]", 2);
				scrollToElement(driver, driver.findElement(By.xpath("//input[@type='submit']")));
				waitTillElementVisible(driver, "//input[@type='submit']", 5);
				driver.findElement(By.id("newGitBranch")).click();
				wait(1000);
				List<WebElement> branchList = driver.findElements(By.xpath(".//select[@id='newGitBranch']//option"));
				for (int i=1;i<branchList.size();i++) {
					if(branchName.equalsIgnoreCase("develop") && branchList.get(i).getText().toLowerCase().equalsIgnoreCase("develop")) {
						sb.append("  <tr>");
						sb.append ("  </tr>");
						sb.append(" ");
						sb.append("  <tr>");
						sb.append ("  </tr>");
						sb.append("Deploying " + environment + " to :: " + branchList.get(i).getText());
						sb.append("  <tr>");
						sb.append ("  </tr>");
						System.out.println("Deploying " + environment + " to :: " + branchList.get(i).getText());
						branchList.get(i).click();
					}
					else if((!branchName.equalsIgnoreCase("develop")) && branchList.get(i).getText().toLowerCase().contains(branchName)) {
						sb.append("  <tr>");
						sb.append ("  </tr>");
						sb.append(" ");
						sb.append("  <tr>");
						sb.append ("  </tr>");
						sb.append("Deploying " + environment + " to :: " + branchList.get(i).getText());
						sb.append("  <tr>");
						sb.append ("  </tr>");
						System.out.println("Deploying " + environment + " to :: " + branchList.get(i).getText());
						branchList.get(i).click();
						break;
					}
				}
				wait(1000);
				driver.findElement(By.xpath(".//input[@type='submit']")).click();
				wait(500);
				waitTillElementVisible(driver, ".//select[@id='teamID']", 5);
				scrollToElement(driver, driver.findElement(By.linkText("Cloud")));
				waitTillElementVisible(driver, ".//a[contains(text(),'Cloud')]", 5);
			}
			else {

				sb.append("  <tr>");
				sb.append ("  </tr>");
				sb.append(" ");
				sb.append("  <tr>");
				sb.append ("  </tr>");
				sb.append("Deploying " + environment + " to :: " + driver.findElement(By.xpath(".//font[contains(text(),'"+environment+"_BRANCH')]/parent::td/following-sibling::td[2]/font")).getText() + "    [No Branch Change]  " );
				sb.append("  <tr>");
				sb.append ("  </tr>");
				sb.append("  <tr>");
				sb.append ("  </tr>");
				System.out.println("Deploying " + environment + " to :: " + driver.findElement(By.xpath(".//font[contains(text(),'"+environment+"_BRANCH')]/parent::td/following-sibling::td[2]/font")).getText() + "    [No Branch Change]  " );
			}
		}
	}

	public static void waitTillElementVisible(WebDriver driver, String XPATH,int timeoutInSeconds) {
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPATH)));
	}

	public static String generateRandomString(int length) {
		if (length < 1) throw new IllegalArgumentException();
		StringBuilder sb = new StringBuilder(length);
		for (int i = 0; i < length; i++) {
			// 0-62 (exclusive), random returns 0-61
			int rndCharAt = random.nextInt(DATA_FOR_RANDOM_STRING.length());
			char rndChar = DATA_FOR_RANDOM_STRING.charAt(rndCharAt);
			// debug
			sb.append(rndChar);
		}
		return sb.toString();
	}

	public static void sendMail() {
		String s = sb.toString();
		messageBody = s;

		String host = "mailrelay.test.aus.netspend.net";
		String emailId = null;

		//Get the session object
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
//		Session session=Session.getInstance(properties,null);   
//		MimeMessage message;

		emailId =  username+"@netspend.com";
		//compose the message
		try {
//			message = new MimeMessage(session);
			//			message.setFrom(new InternetAddress("no-reply@CloudDeploymentReport.com"));
//			message.setFrom(new InternetAddress("no-reply@hgupta.com"));
//			message.setSubject("Deployment Report of CLOUDE");
//			message.addRecipient(Message.RecipientType.TO, new InternetAddress(emailId));
//			message.addRecipient(Message.RecipientType.BCC, new InternetAddress("hgupta@netspend.com"));
//			message.setContent(messageBody, "text/html");
//			Transport.send(message);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
