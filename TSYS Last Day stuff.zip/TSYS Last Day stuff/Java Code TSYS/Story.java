import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Story {
	
	static String username = "hgupta";
	static String password = "Tsys@2027";

	public static void main(String[] args) {
		
//		For cmd : uncomment following
//		username = args[0];
//		password = args[1];
//		System.out.println("Number of Story IDs given : "  + (args.length-2));

//		For cmd : comment following
		args = new String[]{username,password,"PAN-1822"};
		System.out.println("Number of Story IDs given : "  + args.length);

		String Summary = null;
		String Description = null;
		WebDriver driver = null;

		// Set System Properties
		System.out.println("Setting system properties");
		String path = System.getProperty("user.dir");
		System.out.println("System properties are set");
		// Current Dir Path :
		System.out.println("current directory path is :: " + path);
		// instantiating driver
		System.out.println("Instatiating Chrome driver");
		path = path + "\\chromedriver.exe";
		System.out.println("Path for Chrome Driver is ::" + path);
		System.setProperty("webdriver.chrome.driver", path);
		for (int count=2;count<args.length;count++) {
			System.out.println("Opening Chrome Browser");
			driver = new ChromeDriver();
			System.out.println("Browser Opened");
//			System.out.println("opening JIRA and Updating tasks for Story ID : " + args[count]);
			driver.get("https://jira.corp.netspend.com/login.jsp");
			waitForTime(5000);
			System.out.println("// Sending login name");
			driver.findElement(By.xpath(".//input[@id='login-form-username']")).sendKeys(username);
			waitForTime(2000);
			System.out.println("// Sending Password");
			driver.findElement(By.xpath(".//input[@id='login-form-password']")).sendKeys(password);
			waitForTime(2000);
			System.out.println("// Clicking Login Btn");
			driver.findElement(By.xpath(".//input[@id='login-form-submit']")).click();
			waitForTime(5000);
			System.out.println("// Opening Story");
			driver.get("https://jira.corp.netspend.com/browse/" + args[count]);
			waitForTime(5000);

			for (int taskCount=0;taskCount<=3;taskCount++) {
				
				if(taskCount==0) {
					Summary = "QA | Test Case Creation";
					Description = "This task is for test case creation";
				}
				if(taskCount==1) {
					Summary = "QA | Test Case Review";
					Description = "This task is for test case review";
				}
				if(taskCount==2) {
					Summary = "QA | Test case Execution";
					Description = "This task is for test case Execution";
				}
				if(taskCount==3) {
					Summary = "QA | Database Verification Task";
					Description = "This task is validate the database script";
				}
				System.out.println("// Clicking More Button");
				driver.findElement(By.xpath(".//span[contains(text(),'More')]")).click();
				waitForTime(2000);
				System.out.println("// Scrolling down to Create Subtask");
				WebElement subTaskBtn = driver.findElement(By.xpath(".//span[contains(text(),'Create sub-task')]"));
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].scrollIntoView();", subTaskBtn);
				System.out.println("// clicking create subtask btn");
				driver.findElement(By.xpath(".//span[contains(text(),'Create sub-task')]")).click();
				waitForTime(5000);
				System.out.println("Selecting Issue Type");
				driver.findElement(By.id("issuetype-field")).click();
				driver.findElement(By.id("issuetype-field")).clear();
				driver.findElement(By.id("issuetype-field")).sendKeys("QA Task");
				waitForTime(2000);
				driver.findElement(By.id("issuetype-field")).sendKeys(Keys.TAB);
				waitForTime(4000);
				System.out.println("// Summary");
				driver.findElement(By.id("summary")).sendKeys(Summary);
				waitForTime(1000);
				System.out.println("// Description");
				driver.switchTo().frame(driver.findElement(By.xpath(".//iframe[contains(@id,'mce')]")));
				driver.findElement(By.id("tinymce")).sendKeys(Description);
				driver.switchTo().defaultContent();
				System.out.println("// Assign to me");
				driver.findElement(By.id("assign-to-me-trigger")).click();
				waitForTime(2000);
				System.out.println("// Click Create btn");
				driver.findElement(By.id("create-issue-submit")).click();
				waitForTime(5000);
				System.out.println("// Scroll to top");
				WebElement More = driver.findElement(By.xpath(".//span[contains(text(),'More')]"));
				js.executeScript("arguments[0].scrollIntoView();", More);
				waitForTime(2000);
				//				driver.quit();
			}
		}
	}


	public static void waitForTime(int Time) {
		try {
			Thread.sleep(Time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
