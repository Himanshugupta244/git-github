import java.util.HashSet;

public class rough {

	public static void main(String[] args) {

		
		HashSet<String> hs = new HashSet<String>();
		
		hs.add("abcd");
		hs.add("asddsafs");
		
		System.out.println(hs);
		
	}

}
