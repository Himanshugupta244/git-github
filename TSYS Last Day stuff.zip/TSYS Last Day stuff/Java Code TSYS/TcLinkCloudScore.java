import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class TcLinkCloudScore {

	static String urls[] = new String[100];
	static String status[] = new String[100];
	static HashMap<String, List<String>> myMap = new HashMap<>();
	static String username = "hgupta";            /*-- args[0]  */    
	static String password = "Summer@2021";       /*-- args[1]  */ 
	static WebDriver  driver = null;
	
	public static void main(String[] args) {
//		username = args[0];
//		password = args[1];
		
		System.out.println("Setting system properties");
		String path = System.getProperty("user.dir");
		System.out.println("System properties are set");

		// Current Dir Path :
		System.out.println("current directory path is :: " + path);

		// instantiating driver
		System.out.println("Instatiating Chrome driver");
		path = path + "\\chromedriver.exe";
		System.out.println("Path for Chrome Driver is ::" + path);
		System.setProperty("webdriver.chrome.driver", path);

		// Opening chrome browser
		System.out.println("Opening Chrome Browser");
		driver = new ChromeDriver();
		System.out.println("Browser Opened");

		// Going to open JIRA
		System.out.println("Going to Open JIRA");
		driver.get("https://jira.corp.netspend.com/login.jsp");
		waitForTime(2000);

		// Sending JIRA credentials
		System.out.println("// Sending login name");
		driver.findElement(By.xpath(".//input[@id='login-form-username']")).sendKeys(username); 
		waitForTime(2000);
		System.out.println("// Sending Password");
		driver.findElement(By.xpath(".//input[@id='login-form-password']")).sendKeys(password);  
		waitForTime(2000);
		System.out.println("// Clicking Login Btn");
		driver.findElement(By.xpath(".//input[@id='login-form-submit']")).click();
		driver.manage().window().maximize();
		waitForTime(5000);

		// Opening JIRA Dashboard
		driver.findElement(By.xpath("//*[@id='find_link']")).click();
		waitForTime(1000);
		driver.findElement(By.xpath("//*[@id='filter_lnk_my_lnk']")).click();
		waitForTime(5000);
		driver.findElement(By.xpath(".//a[@title='Remove criterion']//span")).click();
		waitForTime(4000);

		// Taking all elements (TC Creation tasks)
		List<WebElement> myElements = driver.findElements(By.xpath(".//ol[@class='issue-list']//li[contains(@title,'Creat')]"));
		waitForTime(4000);

		// Checking all TC elements 
		System.out.println("Total Stories are :: " + myElements.size());

		// Take all Story URLs
		for(int count=1;count<=myElements.size();count++) {
			System.out.println("Scrolling to Story :: " + count);
			scrollToElement(driver, myElements.get(count-1));
			waitForTime(1000);
			myElements.get(count-1).click();
			waitForTime(4000);
			urls[count-1] = driver.findElement(By.id("parent_issue_summary")).getAttribute("href");
			System.out.println("Story num " + count + " is :: >>>>>>>>>>> " +  urls[count-1]);
		}


		// Checking all required features
		for(int count=1;count<=myElements.size();count++) {
			driver.get(urls[count-1]);
			if(myMap.get(urls[count-1]) == null) {
				myMap.put(urls[count-1], new ArrayList<String>());
			}
			
			waitUntillElementVisible(driver, ".//a[@id='key-val']");
			waitForTime(2000);
			System.out.println("");
			if(driver.findElements(By.xpath(".//strong[contains(text(),'TestCollab Execution Link')]")).size()>0)
			{
				System.out.println("1) PASS ---- Test Collab Link Attached for Story :: " + urls[count-1]);
				status[0] = "PASS";
				myMap.get(urls[count-1]).add(status[0]);
			}
			else 
			{
				System.out.println("1) FAIL ############################ Test Collab Link is not attached for Story :: " + urls[count-1]);
				status[0] = "FAIL";
				myMap.get(urls[count-1]).add(status[0]);
			}
			if(driver.findElements(By.xpath(".//strong[contains(text(),'Cloud Usage Score')]")).size()>0)
			{
				System.out.println("2) PASS ---- Cloud Usage Score updated for Story :: " + urls[count-1]);
				status[1] = "PASS";
				myMap.get(urls[count-1]).add(status[1]);
			}
			else 
			{
				System.out.println("2) FAIL ############################ Cloud Usage Score is not updated  for Story :: " + urls[count-1]);
				status[1] = "FAIL";
				myMap.get(urls[count-1]).add(status[1]);
			}
			if(driver.findElements(By.xpath(".//strong[contains(text(),'Cloud Usage Comment')]")).size()>0)
			{
				System.out.println("3) PASS ---- Cloud Usage Comment updated for Story :: " + urls[count-1]);
				status[2] = "PASS";
				myMap.get(urls[count-1]).add(status[2]);
			}
			else 
			{
				System.out.println("3) FAIL ############################ Cloud Usage Comment is not updated  for Story :: " + urls[count-1]);
				status[2] = "FAIL";
				myMap.get(urls[count-1]).add(status[2]);
			}
			if(driver.findElements(By.xpath(".//div[@class='issuePanelContainer']//p[contains(text(),'close the story')]")).size()>0)
			{
				System.out.println("4) PASS ---- Testing Completion comment has been added to story :: " + urls[count-1]);
				status[3] = "PASS";
				myMap.get(urls[count-1]).add(status[3]);
			}
			else
			{
				System.out.println("4) FAIL ############################ Testing Completion comment has not been added to story :: " + urls[count-1]);
				status[3] = "FAIL";
				myMap.get(urls[count-1]).add(status[3]);
			}
			
			int totalTasks = driver.findElements(By.xpath(".//td[@class='stsequence']")).size();
			int tasksClosed = driver.findElements(By.xpath(".//td//div[@class='subtask-done']")).size();

			if(totalTasks==tasksClosed)
			{
				System.out.println("5) PASS ---- all Dev/QA tasks created under this story are closed");
				status[4] = "PASS";
				myMap.get(urls[count-1]).add(status[4]);
			}
			else
			{
				System.out.println("5) FAIL ############################ one/many task(s) under this story is/are not closed");
				status[4] = "FAIL";
				myMap.get(urls[count-1]).add(status[4]);
			}

			driver.get(urls[count-1]);
			waitUntillElementVisible(driver, ".//a[@id='key-val']");
			waitForTime(2000);
			if(driver.findElements(By.xpath(".//a[@class='issue-link'][contains(text(),'Execution')]")).size()>0) {
				System.out.println("6) PASS ---- TC Exection Task name is correct");
				status[5] = "PASS";
				myMap.get(urls[count-1]).add(status[5]);
				scrollToElement(driver, driver.findElement(By.xpath(".//a[@class='issue-link'][contains(text(),'Execution')]")));
				waitForTime(1000);
				driver.findElement(By.xpath(".//a[@class='issue-link'][contains(text(),'Execution')]")).click();
				waitUntillElementVisible(driver, ".//a[@id='key-val']");
				waitForTime(2000);
				if(driver.findElements(By.xpath(".//a[@class='attachment-title'][contains(text(),'')]")).size()>0) {
					System.out.println("7) PASS ---- Log file is attached in TC execution task of story :: " + urls[count-1]);
					status[6] = "PASS";
					myMap.get(urls[count-1]).add(status[6]);
				}
				else
				{
					System.out.println("7) FAIL ############################ Log file is not attached in TC execution task of story :: " + urls[count-1]);
					status[6] = "FAIL";
					myMap.get(urls[count-1]).add(status[6]);
				}
			}
			else {
				System.out.println("6) FAIL ############################ TC Exection Task name is not correct");
				status[5] = "FAIL";
				myMap.get(urls[count-1]).add(status[5]);
				status[6] = "FAIL";
				myMap.get(urls[count-1]).add(status[6]);
			}


			driver.get(urls[count-1]);
			waitUntillElementVisible(driver, ".//a[@id='key-val']");
			waitForTime(2000);
			if(driver.findElements(By.xpath(".//a[@class='issue-link'][contains(text(),'Creation')]")).size()>0) {
				System.out.println("8) PASS ---- TC Creation Task name is correct");
				status[7] = "PASS";
				myMap.get(urls[count-1]).add(status[7]);
				scrollToElement(driver, driver.findElement(By.xpath(".//a[@class='issue-link'][contains(text(),'Creation')]")));
				waitForTime(1000);
				driver.findElement(By.xpath(".//a[@class='issue-link'][contains(text(),'Creation')]")).click();
				waitUntillElementVisible(driver, ".//a[@id='key-val']");
				waitForTime(2000);
				if(driver.findElements(By.xpath(".//a[contains(@href,'pull-request')]")).size()>0) {
					System.out.println("9) PASS ---- Pull request link is added in TC creation task");
					status[8] = "PASS";
					myMap.get(urls[count-1]).add(status[8]);
				}
				else 
				{
					System.out.println("9) FAIL ############################ Pull request link is not added in TC creation task");
					status[8] = "FAIL";
					myMap.get(urls[count-1]).add(status[8]);
				}
			}
			else 
			{
				System.out.println("8) FAIL ---- TC Creation Task name is not correct");
				status[7] = "FAIL";
				myMap.get(urls[count-1]).add(status[7]);
				status[8] = "FAIL";
				myMap.get(urls[count-1]).add(status[8]);
			}
			
		}
		
		// Sending mail 
					System.out.println("***********************************Sending Email to " + username + "****************************************************************");
					sendMail(myElements);
					waitForTime(60000);
					System.out.println("******************Mail Sending Done***************************");
					driver.quit();

	}

	public static void waitForTime(int Time) {
		try {
			Thread.sleep(Time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void scrollToElement(WebDriver driver, WebElement Element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", Element);
	}

	public static void waitUntillElementVisible(WebDriver driver, String xPathOfElement) {
		WebDriverWait wait = new WebDriverWait(driver, 15);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xPathOfElement)));

	}

	public static void sendMail(List<WebElement> myElements) {

		String host = "mail.hq.netspend.com";
		String emailId = null;

		//Get the session object
		Properties properties = System.getProperties();
		properties.setProperty("mail.smtp.host", host);
		Session session=Session.getInstance(properties,null);   
		MimeMessage message;

		emailId =  username+"@netspend.com";
		String feature[] = new String[100];
		feature[0]="Test Collab Link attached in the story ";
		feature[1]="Cloud usage Score added in the story ";
		feature[2]="Cloud comment added in the story ";
		feature[3]="Testing completion comment added in the story ";
		feature[4]="All Dev/QA tasks in this story are closed";
		feature[5]="TC Execution -  Task Name is correct";
		feature[6]="Log file is attached in TC Execution task";
		feature[7]="TC Creation - task name is correct";
		feature[8]="Pull request added in TC Creation story";


		StringBuilder sb = new StringBuilder();
		sb.append("<table class=\"auto-index\">");
		sb.append("<tbody>");
		sb.append("  <tr>");
		sb.append ("  <td colspan=\"7\" style=\"text-align: center;font-weight: bold;background-color: #00FF00;\">StoryIDs : </td>");
		sb.append ("  <td colspan=\"7\" style=\"text-align: center;font-weight: bold;background-color: #00FF00;\">Features Required : </td>");
		sb.append ("  <td colspan=\"7\" style=\"text-align: center;font-weight: bold;background-color: #00FF00;\">Status : </td>");

		for(int count=1;count<=myElements.size();count++) {
			for(int fCount=0;fCount<=8;fCount++) {
				sb.append("  <tr>");
				sb.append ("  <td colspan=\"7\" style=\"text-align: center;font-weight: bold;background-color: #F0F8FF;\">" +urls[count-1]+ " : </td>");
				sb.append ("  <td colspan=\"7\" style=\"text-align: center;font-weight: bold;background-color: #FFF8DC;\">" + feature[fCount]   + " </td>");
				if(myMap.get(urls[count-1]).get(fCount).equalsIgnoreCase("PASS"))
				sb.append ("  <td colspan=\"7\" style=\"text-align: center;font-weight: bold;background-color: #98FB98;\">" + myMap.get(urls[count-1]).get(fCount)  + " </td>");
				else 
					sb.append ("  <td colspan=\"7\" style=\"text-align: center;font-weight: bold;background-color: #FF0000;\">" + myMap.get(urls[count-1]).get(fCount)  + " </td>");
				sb.append ("  </tr>");
			}
			sb.append("  <tr>");
			sb.append ("  </tr>");
			sb.append("  <tr>");
			sb.append ("  </tr>");
		}
		sb.append ("  </tr>");
		sb.append("  <br><br> Thanks <br> Enterprise Team");

		String s = sb.toString();
		String messageBody = s;

		//compose the message
		try {
			message = new MimeMessage(session);
			message.setFrom(new InternetAddress("no-reply@EnterpriseTeam.com"));
			message.setSubject("QA Compliance check for : " + username +"@netspend.com");
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(emailId));
			message.setContent(messageBody, "text/html");
			Transport.send(message);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}
}
