-- Entry of the active Paycard account should be there in cit_user table :
Select user_id, LEGAL_ID, FEE_LEGAL_ID, cit_date, processed, errored, support_note_processed, support_note_errored,support_note from ns_int.cit_user 
where user_id = hextoraw('AC1574C2B32EBC3B000001697702CA2184A3');
-- "processed" value should be there as "0" in cit_user table :
Select processed, errored, support_note_processed, support_note_errored from ns_int.cit_user where user_id = hextoraw('AC1574C33F985036000001697604E3E0871E');
-- "processed" value in cit_user table should be changed to "1" when migration is done.
Select processed, errored, support_note_processed, support_note_errored from ns_int.cit_user where user_id = hextoraw('AC1574C33F985036000001697604E3E0871E');
-- "support_note_processed" should be 0 in cit_user table
Select processed, errored, support_note_processed, support_note_errored,support_note from ns_int.cit_user where user_id = hextoraw('AC1574C2B32EBC3B000001697702CA21851B');



-- Insert Queries and Update Queries
insert into ns_int.cit_user (user_id, LEGAL_ID, FEE_LEGAL_ID, cit_date, processed, errored, support_note_processed, support_note_errored)
values (hextoraw('AC1574C2B32EBC3B000001697702CA2184A3'), 'Legal201711070319298', '550340418', TO_DATE('14-MAR-2019','DD-MON-YYYY'), 0, 0, 0, 0);
commit;
-- update support Note
Update ns_int.cit_user Set support_note = 'SupportNoteForPaycardTermMigration' where user_id = hextoraw('AC1574C2B32EBC3B000001697702CA2184A3');
commit;


-- LegalIDs - Legal201711070319298, Fee_LegalId - 550340418
-- LegalIDs - Legal201714100828721, Fee_LegalId - 510587418
