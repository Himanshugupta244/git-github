-- new terms should be there in term table
Select * from term where name in ('Legal201711070319298','550340418');
-- On Fee Type Term, there should be a planID
Select plan_id from Group_fee_plan where group_id in (Select group_id from tier where term_id in (Select term_id from term where name = '510587418')); -- 787149
-- Check that correct fees should be displayed for this PlanID in tCam
Select ft.description as Fee_Name,f.description as Amount_To_Be_Charged from fee_subscription_plan fsp, fee f,fee_type ft where fsp.plan_id = 786800 and fsp.fee_package_id = f.fee_package_id and ft.fee_type_id = f.fee_type_id;
-- check all terms of user 
Select ts.term_id,t.name,ts.effective_date,ts.end_date,t.term_type_id from term_subscription ts,term t where user_id = hextoraw('AC1574C2B32EBC3B000001697702CA218443') and ts.term_id=t.term_id order by effective_date;