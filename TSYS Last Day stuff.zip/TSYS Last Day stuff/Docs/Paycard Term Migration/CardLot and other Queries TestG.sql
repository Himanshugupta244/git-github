Select * from term_subscription where user_id = hextoraw('AC1561931AF32AB40000014F9AE4B205C7A9');
Select * from term where term_id = hextoraw('1440759731273B5FE053136015AC7EC80000');
Select * from term_document where term_id in (Select term_id from term where term_type_id = 5 and rowNum < 8000) and location not in ('SomeFeeScheduleTermsDoc.pdf1','SFLF_550484119_EN.pdf');
Select * from term_document where term_id = hextoraw('AC156193B487C165000001603796003E8001');
--  Before Migration, check the entry in Account_subscription table and check its existing planID
Select * from users where user_id = hextoraw('AC1574C3127F775A000001696E6DBFF0C216');
Select * from account_subscription where account_id = hextoraw('AC1574C3127F775A000001696E6DBFF0C215');

-- After migration, Take group_id of these 2 new terms from "term" table and check that 2 new entries should be inserted in "group_user" table for the combination of your userid and these group_ids
Select * from term where term_id = hextoraw('AC156193DB05D5DF00000155DE00E37C0F6D');
Select * from term where term_id = hextoraw('AC15617682E220DB0000016686B5FD19492A');
Select * from group_user where group_id = hextoraw('17173F12A2153AF9E053146015AC446C0000') and user_id = hextoraw('AC1574C3127F775A000001696E6DBFF0C216');
Select * from group_user where group_id = hextoraw('AC15617682E220DB0000016686B5FD194929') and user_id = hextoraw('AC1561931AF32AB40000014F9AE4B205CA0A');
-- After migration, Take group_id of 2 new tiers for your terms from "tier" table and check that 1 new entry should be inserted in "group_user" table for the combination of your userid and these group_ids 
--(That group_id should be inserted in Group_user table corresponding to the tier which is associated with term_type_id = 5)
Select * from tier where term_id = hextoraw('AC156193DB05D5DF00000155DE00E37C0F6D'); -- take GroupID from tier table
Select * from tier where term_id = hextoraw('AC15617682E220DB0000016686B5FD19492A'); -- take GroupID from tier table
Select * from group_user where group_id = hextoraw('AC156193DB05D5DF00000155DE00E37C0F6E') and user_id = hextoraw('AC1561931AF32AB40000014F9AE4B205CA0A');
Select * from group_user where group_id = hextoraw('AC15617682E220DB0000016686B5FD19492B') and user_id = hextoraw('AC1561931AF32AB40000014F9AE4B205CA0A');

-- After migration, 1 new entry should be inserted in "account_subscription" table for mew plan_id 
-- After migration, previous entry should be expired and "EXPIRATION_DATE" should be same as "Effective_Date" of new plan (Same as "cit_date" of "cit_user" table in "ns_int" database)
-- After migration, check the insert date and modified date of both the entries (Previos and new entry)
Select * from account_subscription where account_id = (Select account_id from users where user_id = hextoraw('AC1561931AF32AB40000014F9AE4B205CA0A'));

Select login_name from users where user_id = hextoraw('AC1574C23CD153F2000001696E6F7DFBC2CF');
Select user_id from users where account_id = hextoraw('AC1574C23CD153F2000001696E6F7DFBC2CE');
Select * from account_subscription where account_id = hextoraw('AC1574C23CD153F2000001696E6F7DFBC2CE');--planid 185
select * from users where account_id=hextoraw('AC1574C23CD153F2000001696E6F7DFBC2CE');
select * from tier_subscription where user_id=hextoraw('AC1574C23CD153F2000001696E6F7DFBC2CF');


UPDATE netspend.users u
SET u.password_hash=ns_crypt.getNSHash('password')
WHERE u.login_name = 'AC1574C33F985036000001697604E3E0871F';
Select * from account_transaction where debit_account_id = hextoraw('AC1574C3127F775A000001696E6DBFF0C215');

Update users Set login_name = 'HimanshuDemoAccount20' where login_name = 'AC1574C2B32EBC3B000001697702CA21842C';

-----------------------------------------------------------------------------------------------------------
Select lot_id from prepaid_card_lot where description like '%HimanshuFinalLotForDemo%';
Select pseudo_pan from prepaid_card where lot_id = (Select lot_id from prepaid_card_lot where description like '%HimanshuFinalLotForDemo%');
Select account_id from account_pan_binding where pseudo_pan in (Select pseudo_pan from prepaid_card where lot_id = (Select lot_id from prepaid_card_lot where description like '%HimanshuFinalLotForDemo%'));
Select account_id,user_id,users.login_name from users where account_id in (Select account_id from account_pan_binding where pseudo_pan in (Select pseudo_pan from prepaid_card where lot_id = (Select lot_id from prepaid_card_lot where description like '%HimanshuFinalLotForDemo%')));
Select * from users where login_name = 'HimanshuDemoAccount1';
Select * from users where user_id = hextoraw('AC1561931AF32AB40000014F9AE4B205C7A9');
Select * from cash_numbers_used where cash_number = 7121723952;
Select * from term where name in ('Legal201711070319298','Legal201714100828721');
________________________________________________________________________________________________________

Select user_id from users where account_id in (Select account_id from account where account_type = 4 and rownum <= 10);
Select * from term_subscription where user_id in (Select user_id from users where account_id in (Select account_id from account where account_type = 4 and rownum <= 10));

Select * from group_fee_plan where plan_id = 11773;
Select * from groups where group_id = hextoraw('AC156193151133E700000159256227A25146');
Select * from group_type where group_type_id = hextoraw('E0CBF6DC8D5522C6E043136015ACF1D30000');
________________________________________________________________________________________________________

Select distinct user_id from term_subscription where user_id in (Select user_id from users where account_id in (Select account_id from account where account_type = 4 and rownum <= 10));
Select * from users where user_id = hextoraw('AC1561931AF32AB40000014F9AE4B205EA23');
Select * from term_subscription where user_id = hextoraw('AC1561931AF32AB40000014F9AE4B205CC08');
