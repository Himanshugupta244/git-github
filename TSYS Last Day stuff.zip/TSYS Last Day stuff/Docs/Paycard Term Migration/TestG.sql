Select user_id,account_id,login_name from users where account_id = hextoraw('AC1574C3127F775A00000169743AAEF6B6B7');
Select * from users where user_id = hextoraw('AC1574C3AB3C9D420000016975D1E6A18009');
Select * from term_subscription where user_id = hextoraw('AC1574C3AB3C9D420000016975D1E6A18009') order by effective_date;
Select * from term where term_id = hextoraw('156BB2473044AA4EE053136015AC97150000');
-- See Plan ID
    -- User Specific
Select * from account_subscription where account_id = hextoraw('AC1574C3AB3C9D420000016975D1E6A18008') order by effective_date;
    -- User New Term Specific
Select * from group_fee_plan where group_id = (Select group_id from tier where term_id = (Select term_id from term where term_id in (Select term_id from term_subscription where user_id = hextoraw('AC1574C3AB3C9D420000016975D1E6A18009')) and term_type_id = 5));
    -- Migration Term Specific
Select * from group_fee_plan where group_id in (Select group_id from tier where term_id in (Select term_id from term where name = '550340418'));
-- See User's Terms
Select t.term_id,name as Term_Name,ts.effective_date,ts.End_date,term_type_id from term_subscription ts, term t where t.term_id = ts.term_id and ts.user_id = hextoraw('AC1574C3127F775A00000169743AAEF6B664') order by ts.effective_date;
Select t.name,tt.name,gfp.plan_id from term t, tier tt, group_fee_plan gfp where t.name = '550340418' and t.term_id = tt.term_id and tt.group_id = gfp.group_id;
-- Select f.description from fee_subscription_plan fsp, fee f where fsp.plan_id = 787149 and fsp.fee_package_id = f.fee_package_id;


Select * from term_document td, term t where t.term_id = td.term_id and t.name in ('Legal201711070319298','550340418');
Update term_document Set location = '010102_2-0.pdf' where term_document_id = hextoraw('37731D7C8811C944E053136015AC43CE0000');
Select * from term_document where location like '%BofI_AUS_MC_Cardholder_Agreement_ENG%';
Select * from term where term_id = hextoraw('14407597312F3B5FE053136015AC7EC80000');
Select * from term_subscription where user_id = hextoraw('AC1574C3AB3C9D420000016975D1E6A18009');  -- term_id = hextoraw('14407597312F3B5FE053136015AC7EC80000')
Select * from prepaid_card_lot where description like '%myLotForDemo%';
Select * from prepaid_card where lot_id = hextoraw('AC1574C263E20E63000001697600CE798154');
Select Login_name from users where account_id in (Select account_id from account_pan_binding where pseudo_pan in (Select pseudo_pan from prepaid_card where lot_id = hextoraw('AC1574C263E20E63000001697600CE798154')));
